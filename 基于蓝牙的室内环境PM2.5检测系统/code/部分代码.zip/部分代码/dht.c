#include <reg52.h>
#include <intrins.h>
#include <absacc.h>
#include <math.h>
#include "uart.c"
#include "0832.h"
  
#define uchar unsigned char
#define uint unsigned int

//����LCD1602�˿�
sbit E=P2^6;		//1602ʹ������
sbit RS=P2^7;		//1602����/����ѡ������
sbit RW=P2^5;
//��������
sbit key1=P3^2;
sbit key2=P3^3;
sbit key3=P3^4;
sbit key4=P3^5;
//����������
sbit beep=P2^3;
//����LED
sbit led=P3^6;
uint DA;
#define NULL 0
#define RsBuf_N	120
bit FlagStartRH=0;

uint bj=150;


uchar count=0;
unsigned char idata RsBuf[RsBuf_N];	//���崮�ڽ������ݻ�����
uchar RsPoint;
void L1602_string(uchar hang,uchar lie,uchar *p);

//��ʱ��0��ʼ��
void Timer0_Init()
{
	ET0 = 1;        //������ʱ��0�ж�
	TMOD = 0x21;       //��ʱ��������ʽѡ��
	TL0 = 0xFF;     
	TH0 = 0x4B;     //��ʱ�������ֵ
	TR0 = 1;        //������ʱ��
}

//��ʱ��0�ж�
void Timer0_ISR (void) interrupt 1 using 0
{
	uchar RHCounter;
	TL0 = 0xFF;
	TH0 = 0x4B;     //��ʱ�������ֵ
	RHCounter++;
	//ÿ2��������һ����ʪ��ת��
    if (RHCounter >= 20)
    {
       FlagStartRH = 1;
	   RHCounter = 0;
    }
}

void Delay1(uint j)
{
    uchar i;
    for(;j>0;j--)
    { 	
		for(i=0;i<27;i++);
    }
} 

/********************************************************************
* �ļ���  �� Һ��1602��ʾ.c
* ����    :  �ó���ʵ���˶�Һ��1602�Ŀ��ơ�
***********************************************************************/


/********************************************************************
* ���� : delay()
* ���� : ��ʱ,��ʱʱ����Ϊ140US��
* ���� : ��
* ��� : ��
***********************************************************************/

void delay()
{
	int i,j;
	for(i=0; i<=10; i++)
	for(j=0; j<=2; j++);
}

void delay_ms(uint ms)
{
	uint i,j;
	for(i=0;i<ms;i++)
	for(j=0;j<110;j++);
} 	  
	
/********************************************************************
* ���� : enable(uchar del)
* ���� : 1602�����
* ���� : ���������ֵ
* ��� : ��
***********************************************************************/

void enable(uchar del)
{
	P0 = del;
	RS = 0;
	E = 1;
	delay();
	E = 0;
	delay();
}

/********************************************************************
* ���� : write(uchar del)
* ���� : 1602д���ݺ���
* ���� : ��Ҫд��1602������
* ��� : ��
***********************************************************************/

void write(uchar del)
{
	P0 = del;
	RS = 1;
	E = 1;
	delay();
	E = 0;
	delay();
}

/********************************************************************
* ���� : L1602_init()
* ���� : 1602��ʼ������ο�1602������
* ���� : ��
* ��� : ��
***********************************************************************/
void L1602_init(void)
{
	
	enable(0x38);
	enable(0x0c);
	enable(0x06); 
	enable(0x01); //����Ҫ�������
	enable(0x80);
	L1602_string(1,1,"PM2.5:     ug/m3");
	L1602_string(2,1,"PMBEEP:    ug/m3");
}

/********************************************************************
* ���� : L1602_char(uchar hang,uchar lie,char sign)
* ���� : �ı�Һ����ĳλ��ֵ�����Ҫ�õ�һ�У�������ַ���ʾ"b" �����øú�������
		 L1602_char(1,5,'b')
* ���� : �У��У���Ҫ����1602������
* ��� : ��
***********************************************************************/
void L1602_char(uchar hang,uchar lie,char sign)
{
	uchar a;
	if(hang == 1) a = 0x80;
	if(hang == 2) a = 0xc0;
	a = a + lie - 1;
	enable(a);
	write(sign);
}

/********************************************************************
* ���� : L1602_string(uchar hang,uchar lie,uchar *p)
* ���� : �ı�Һ����ĳλ��ֵ�����Ҫ�õ�һ�У�������ַ���ʼ��ʾ"ab cd ef" �����øú�������
	 	 L1602_string(1,5,"ab cd ef;")
* ���� : �У��У���Ҫ����1602������
* ��� : ��
***********************************************************************/
void L1602_string(uchar hang,uchar lie,uchar *p)
{
	uchar a;
	if(hang == 1) a = 0x80;
	if(hang == 2) a = 0xc0;
	a = a + lie - 1;
	enable(a);
	while(1)
	{
		if(*p == '\0') break;
		write(*p);
		p++;
	}
}

void display()
{
    if(DA%10000/1000!=0)
	L1602_char(1,8,DA%10000/1000+0x30);
	else
	L1602_char(1,8,' ');

	if(DA%10000/100!=0)
	L1602_char(1,9,DA%1000/100+0x30);
	else
	L1602_char(1,9,' ');

	if(DA%10000/10!=0)
	L1602_char(1,10,DA%100/10+0x30);
	else
	L1602_char(1,10,' ');

	L1602_char(1,11,DA%10+0x30);

   	L1602_char(2,9,bj/100+0x30);
	L1602_char(2,10,bj%100/10+0x30);
	L1602_char(2,11,bj%10+0x30);
}
//  ͨѶ�жϽ��ճ���   �жϺ����޷���ֵ
  void uart_rx(void)  interrupt 4	using 3	  //�������� �ͷ���main����������һ����
 {

   	if((RsPoint<RsBuf_N)&&RI) //�����ж�RI�Ƿ�Ϊ1

    {
    	RI=0;
    	RsBuf[RsPoint++]=SBUF;
    }

 }


/********************************************************************
* ���� : Main()
* ���� : ������
***********************************************************************/
void main()
{
	uchar h;
	uchar keyflag=0,key2flag=0;
	uint shuju[40];
	uint sum;
    EA = 0;
	Timer0_Init();  //��ʱ��0��ʼ��
	Uart_init();
	EA = 1;
	RW=0;
	L1602_init();
	display();
	for(h=0;h<40;h++)	{shuju[h]=0;}
//	bj=rdeeprom(1);	 
	delay_ms(100);		 //����ʱ���Դ�ȡ�ȶ�
	while(1)
	{
		if((keyflag==0)&&(key2flag==0))
		{
			if(key1==0)
			{
			delay_ms(5);
			if(key1==0)
			{
			keyflag++;
			beep=0;
			L1602_char(2,7,'C');
			while(key1==0);
			beep=1;
			}
			}

			if(key2==0)
			{
			delay_ms(5);
			if(key2==0)
			{
			key2flag++;
			enable(0x01);
			beep=0;
			while(key2==0);
			beep=1;
			}
			}

		 if ((FlagStartRH == 1))	 //��ʪ��ת����־���
		 {
		     TR0 = 0;
			for(h=0;h<20;h++)
			{
				DA=adc0832(0);
				sum=sum+DA;
				delay_ms(100);
				
			}
			DA=sum/20;
			sum=0;
			DA=DA*11.76;//((float)(DA/2))*4;

            if(DA>bj)
			{
			beep=0;
			led=0;
			shuju[count]=DA;
			if(count<40){count++;} else{count=0;}

			}
			else
			{
			beep=1;
			led=1;
			}


			display();
			SendASC('P');
			SendASC('M');
			SendASC('2');
			SendASC('.');
			SendASC('5');
			SendASC(':');
			if(DA%10000/1000!=0)
			SendASC(DA%10000/1000+0x30);
			if(DA%10000/100!=0)
			SendASC(DA%1000/100+0x30);
			if(DA%10000/10!=0)
			SendASC(DA%100/10+0x30);
			SendASC(DA%10+0x30);
			SendString("ug/m3");
			SendString("\n\n\n");
			TR0 = 1;
		}
		}
		if((keyflag>0)&&(key2flag==0))
		{
		
			if(key4==0)
			{
			delay_ms(5);
			 if(key4==0)
			 {
			 keyflag=0;
			 beep=0;
			 L1602_char(2,7,':');
			 while(key4==0);
			 beep=1;
			 }
			}
		
			if(keyflag>0)
			{
			 if(key2==0)
			{
			 delay_ms(5);
			 if(key2==0)
			 {
			 beep=0;
			 while(key2==0);
			 beep=1;
			 if(bj<1000) bj++;
			 }
			}
		
			 if(key3==0)
			{
			 delay_ms(5);
			 if(key3==0)
			 {
			 beep=0;
			 while(key3==0);
			 beep=1;
			 if(bj>0) bj--;
			 }
			}
			}
		    display();	
			}
		if((keyflag==0)&&(key2flag>0))
		{
				if(key2==0)
				{
				delay_ms(5);
				if(key2==0)
				{
				if((count/8)==0)    {key2flag=1;}
		 		if((count/8)==1)	
				{
				key2flag++;
				if(key2flag>2) key2flag=1;
				}	 
				if((count/8)==2)	
				{
				if(key2flag>3) key2flag=1;
				key2flag++;
				}	 
				if((count/8)==3)	
				{
				key2flag++;
				if(key2flag>4) key2flag=1;
				}	 
				if((count/8)==4)	
				{
				key2flag++;
				if(key2flag>5) key2flag=1;
				}	  
				beep=0;
				while(key2==0);
				beep=1;
				}
				}
				if(key4==0)
				{
				delay_ms(5);
				 if(key4==0)
				 {
				 key2flag=0;
				 L1602_string(1,1,"PM2.5:     ug/m3");
	             L1602_string(2,1,"PMBEEP:    ug/m3");
				 beep=0;
				 display();
				 while(key4==0);
				 beep=1;
				 }
				}


		 		if(key3==0)
				{
				delay_ms(5);
				 if(key3==0)
				 {
				 for(h=0;h<40;h++)	{shuju[h]=0;}
				 key2flag=0;
				 L1602_string(1,1,"PM2.5:     ug/m3");
	             L1602_string(2,1,"PMBEEP:    ug/m3");
				 beep=0;
				 display();
				 while(key3==0);
				 beep=1;
				 }
				}
//	    if(count/8==0)			//��ʾ0-7
//        {
		 if((key2flag==1)&&((count/8)>=0))
		 {
		  L1602_char(1,1,shuju[0]/100+0x30);
		  L1602_char(1,2,shuju[0]%100/10+0x30);
		  L1602_char(1,3,shuju[0]%10+0x30);
		  L1602_char(1,4,' ');
		  L1602_char(1,5,shuju[1]/100+0x30);
		  L1602_char(1,6,shuju[1]%100/10+0x30);
		  L1602_char(1,7,shuju[1]%10+0x30);
		  L1602_char(1,8,' ');
		  L1602_char(1,9,shuju[2]/100+0x30);
		  L1602_char(1,10,shuju[2]%100/10+0x30);
		  L1602_char(1,11,shuju[2]%10+0x30);
		  L1602_char(1,12,' ');
		  L1602_char(1,13,shuju[3]/100+0x30);
		  L1602_char(1,14,shuju[3]%100/10+0x30);
		  L1602_char(1,15,shuju[3]%10+0x30);
		  L1602_char(1,16,' ');
		  L1602_char(2,1,shuju[4]/100+0x30);
		  L1602_char(2,2,shuju[4]%100/10+0x30);
		  L1602_char(2,3,shuju[4]%10+0x30);
		  L1602_char(2,4,' ');
		  L1602_char(2,5,shuju[5]/100+0x30);
		  L1602_char(2,6,shuju[5]%100/10+0x30);
		  L1602_char(2,7,shuju[5]%10+0x30);
		  L1602_char(2,8,' ');
		  L1602_char(2,9,shuju[6]/100+0x30);
		  L1602_char(2,10,shuju[6]%100/10+0x30);
		  L1602_char(2,11,shuju[6]%10+0x30);
		  L1602_char(2,12,' ');
		  L1602_char(2,13,shuju[7]/100+0x30);
		  L1602_char(2,14,shuju[7]%100/10+0x30);
		  L1602_char(2,15,shuju[7]%10+0x30);
		  L1602_char(2,16,'1');
		 }

		 if((key2flag==2)&&((count/8)>=1))
		 {
		  L1602_char(1,1,shuju[8]/100+0x30);
		  L1602_char(1,2,shuju[8]%100/10+0x30);
		  L1602_char(1,3,shuju[8]%10+0x30);
		  L1602_char(1,4,' ');
		  L1602_char(1,5,shuju[9]/100+0x30);
		  L1602_char(1,6,shuju[9]%100/10+0x30);
		  L1602_char(1,7,shuju[9]%10+0x30);
		  L1602_char(1,8,' ');
		  L1602_char(1,9,shuju[10]/100+0x30);
		  L1602_char(1,10,shuju[10]%100/10+0x30);
		  L1602_char(1,11,shuju[10]%10+0x30);
		  L1602_char(1,12,' ');
		  L1602_char(1,13,shuju[11]/100+0x30);
		  L1602_char(1,14,shuju[11]%100/10+0x30);
		  L1602_char(1,15,shuju[11]%10+0x30);
		  L1602_char(1,16,' ');
		  L1602_char(2,1,shuju[12]/100+0x30);
		  L1602_char(2,2,shuju[12]%100/10+0x30);
		  L1602_char(2,3,shuju[12]%10+0x30);
		  L1602_char(2,4,' ');
		  L1602_char(2,5,shuju[13]/100+0x30);
		  L1602_char(2,6,shuju[13]%100/10+0x30);
		  L1602_char(2,7,shuju[13]%10+0x30);
		  L1602_char(2,8,' ');
		  L1602_char(2,9,shuju[14]/100+0x30);
		  L1602_char(2,10,shuju[14]%100/10+0x30);
		  L1602_char(2,11,shuju[14]%10+0x30);
		  L1602_char(2,12,' ');
		  L1602_char(2,13,shuju[15]/100+0x30);
		  L1602_char(2,14,shuju[15]%100/10+0x30);
		  L1602_char(2,15,shuju[15]%10+0x30);
		  L1602_char(2,16,'2');
		 }

		 if((key2flag==3)&&((count/8)>=2))
		 {
		  L1602_char(1,1,shuju[16]/100+0x30);
		  L1602_char(1,2,shuju[16]%100/10+0x30);
		  L1602_char(1,3,shuju[16]%10+0x30);
		  L1602_char(1,4,' ');
		  L1602_char(1,5,shuju[17]/100+0x30);
		  L1602_char(1,6,shuju[17]%100/10+0x30);
		  L1602_char(1,7,shuju[17]%10+0x30);
		  L1602_char(1,8,' ');
		  L1602_char(1,9,shuju[18]/100+0x30);
		  L1602_char(1,10,shuju[18]%100/10+0x30);
		  L1602_char(1,11,shuju[18]%10+0x30);
		  L1602_char(1,12,' ');
		  L1602_char(1,13,shuju[19]/100+0x30);
		  L1602_char(1,14,shuju[19]%100/10+0x30);
		  L1602_char(1,15,shuju[19]%10+0x30);
		  L1602_char(1,16,' ');
		  L1602_char(2,1,shuju[20]/100+0x30);
		  L1602_char(2,2,shuju[20]%100/10+0x30);
		  L1602_char(2,3,shuju[20]%10+0x30);
		  L1602_char(2,4,' ');
		  L1602_char(2,5,shuju[21]/100+0x30);
		  L1602_char(2,6,shuju[21]%100/10+0x30);
		  L1602_char(2,7,shuju[21]%10+0x30);
		  L1602_char(2,8,' ');
		  L1602_char(2,9,shuju[22]/100+0x30);
		  L1602_char(2,10,shuju[22]%100/10+0x30);
		  L1602_char(2,11,shuju[22]%10+0x30);
		  L1602_char(2,12,' ');
		  L1602_char(2,13,shuju[23]/100+0x30);
		  L1602_char(2,14,shuju[23]%100/10+0x30);
		  L1602_char(2,15,shuju[23]%10+0x30);
		  L1602_char(2,16,'3');
		 }
		 if((key2flag==4)&&((count/8)>=3))
		 {
		  L1602_char(1,1,shuju[24]/100+0x30);
		  L1602_char(1,2,shuju[24]%100/10+0x30);
		  L1602_char(1,3,shuju[24]%10+0x30);
		  L1602_char(1,4,' ');
		  L1602_char(1,5,shuju[25]/100+0x30);
		  L1602_char(1,6,shuju[25]%100/10+0x30);
		  L1602_char(1,7,shuju[25]%10+0x30);
		  L1602_char(1,8,' ');
		  L1602_char(1,9,shuju[26]/100+0x30);
		  L1602_char(1,10,shuju[26]%100/10+0x30);
		  L1602_char(1,11,shuju[26]%10+0x30);
		  L1602_char(1,12,' ');
		  L1602_char(1,13,shuju[27]/100+0x30);
		  L1602_char(1,14,shuju[27]%100/10+0x30);
		  L1602_char(1,15,shuju[27]%10+0x30);
		  L1602_char(1,16,' ');
		  L1602_char(2,1,shuju[28]/100+0x30);
		  L1602_char(2,2,shuju[28]%100/10+0x30);
		  L1602_char(2,3,shuju[28]%10+0x30);
		  L1602_char(2,4,' ');
		  L1602_char(2,5,shuju[29]/100+0x30);
		  L1602_char(2,6,shuju[29]%100/10+0x30);
		  L1602_char(2,7,shuju[29]%10+0x30);
		  L1602_char(2,8,' ');
		  L1602_char(2,9,shuju[30]/100+0x30);
		  L1602_char(2,10,shuju[30]%100/10+0x30);
		  L1602_char(2,11,shuju[30]%10+0x30);
		  L1602_char(2,12,' ');
		  L1602_char(2,13,shuju[31]/100+0x30);
		  L1602_char(2,14,shuju[31]%100/10+0x30);
		  L1602_char(2,15,shuju[31]%10+0x30);
		  L1602_char(2,16,'4');
		 }
		  if((key2flag==5)&&((count/8)>=4))
		 {
		  L1602_char(1,1,shuju[32]/100+0x30);
		  L1602_char(1,2,shuju[32]%100/10+0x30);
		  L1602_char(1,3,shuju[32]%10+0x30);
		  L1602_char(1,4,' ');
		  L1602_char(1,5,shuju[33]/100+0x30);
		  L1602_char(1,6,shuju[33]%100/10+0x30);
		  L1602_char(1,7,shuju[33]%10+0x30);
		  L1602_char(1,8,' ');
		  L1602_char(1,9,shuju[34]/100+0x30);
		  L1602_char(1,10,shuju[34]%100/10+0x30);
		  L1602_char(1,11,shuju[34]%10+0x30);
		  L1602_char(1,12,' ');
		  L1602_char(1,13,shuju[35]/100+0x30);
		  L1602_char(1,14,shuju[35]%100/10+0x30);
		  L1602_char(1,15,shuju[35]%10+0x30);
		  L1602_char(1,16,' ');
		  L1602_char(2,1,shuju[36]/100+0x30);
		  L1602_char(2,2,shuju[36]%100/10+0x30);
		  L1602_char(2,3,shuju[36]%10+0x30);
		  L1602_char(2,4,' ');
		  L1602_char(2,5,shuju[37]/100+0x30);
		  L1602_char(2,6,shuju[37]%100/10+0x30);
		  L1602_char(2,7,shuju[37]%10+0x30);
		  L1602_char(2,8,' ');
		  L1602_char(2,9,shuju[38]/100+0x30);
		  L1602_char(2,10,shuju[38]%100/10+0x30);
		  L1602_char(2,11,shuju[38]%10+0x30);
		  L1602_char(2,12,' ');
		  L1602_char(2,13,shuju[39]/100+0x30);
		  L1602_char(2,14,shuju[39]%100/10+0x30);
		  L1602_char(2,15,shuju[39]%10+0x30);
		  L1602_char(2,16,'5');
		 }
		}

	}
}